

const $ = (id) => document.getElementById(id);

const STORAGE_KEY = "foodshare_demo_foods";
const FEEDBACK_KEY = "foodshare_demo_feedback";

let currentUser = null;
let selectedImage = "";
let foods = loadData(STORAGE_KEY, []);
let feedbacks = loadData(FEEDBACK_KEY, []);

const deliverySteps = [
    "Claimed",
    "Partner Assigned",
    "Picked Up",
    "On the Way",
    "Delivered"
];

function loadData(key, fallback) {
    try {
        const saved = localStorage.getItem(key);
        return saved ? JSON.parse(saved) : fallback;
    } catch {
        return fallback;
    }
}

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(foods));
        localStorage.setItem(FEEDBACK_KEY, JSON.stringify(feedbacks));
        return true;
    } catch {
        alert("Browser storage is full. Try using a smaller food image.");
        return false;
    }
}

function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

function isExpired(food) {
    return new Date(food.expiry).getTime() <= Date.now();
}

function refreshExpiredFood() {
    let changed = false;

    foods.forEach(food => {
        if (food.status === "Available" && isExpired(food)) {
            food.status = "Unclaimed";
            changed = true;
        }
    });

    if (changed) saveData();
}

function statusBadge(status) {
    let style = "";

    if (status === "Unclaimed" || status === "Expired") {
        style = "warning";
    } else if (status === "Delivered" || status === "Sent to Compost") {
        style = "";
    } else if (status === "Available") {
        style = "";
    } else {
        style = "warning";
    }

    return `<span class="badge ${style}">${escapeHTML(status)}</span>`;
}

// DEMO LOGIN
$("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    currentUser = {
        name: $("userName").value.trim(),
        role: $("userRole").value
    };

    if (!currentUser.name) return;

    $("loginSection").hidden = true;
    $("dashboard").hidden = false;

    const titles = {
        donor: "Donor Dashboard",
        receiver: "Receiver Dashboard",
        delivery: "Delivery Dashboard",
        compost: "Compost & Fertilizer Dashboard"
    };

    $("dashboardTitle").textContent =
        `Hello, ${currentUser.name}!`;

    document.querySelectorAll(".role-panel").forEach(panel => {
        panel.hidden = true;
    });

    const panelIds = {
        donor: "donorPanel",
        receiver: "receiverPanel",
        delivery: "deliveryPanel",
        compost: "compostPanel"
    };

    $(panelIds[currentUser.role]).hidden = false;

    // Pre-fill donor name for convenience.
    if (currentUser.role === "donor") {
        $("donorName").value = currentUser.name;
    }

    renderAll();
});

$("logoutButton").addEventListener("click", function() {
    currentUser = null;
    selectedImage = "";
    $("dashboard").hidden = true;
    $("loginSection").hidden = false;
    $("loginForm").reset();
    $("imagePreview").hidden = true;
});

// FOOD IMAGE PREVIEW
$("foodImage").addEventListener("change", function() {
    const file = this.files[0];

    selectedImage = "";
    $("imagePreview").hidden = true;

    if (!file) return;

    if (!file.type.startsWith("image/")) {
        alert("Please select an image file.");
        this.value = "";
        return;
    }

    // Keep images small so localStorage is less likely to fill up.
    if (file.size > 500 * 1024) {
        alert("Please select an image under 500 KB.");
        this.value = "";
        return;
    }

    const reader = new FileReader();

    reader.onload = function() {
        selectedImage = reader.result;
        $("imagePreview").src = selectedImage;
        $("imagePreview").hidden = false;
    };

    reader.onerror = function() {
        alert("Could not read the selected image.");
    };

    reader.readAsDataURL(file);
});

// DONOR: ADD FOOD
$("foodForm").addEventListener("submit", function(event) {
    event.preventDefault();

    if (!currentUser || currentUser.role !== "donor") return;

    const expiry = $("expiry").value;
    const expiryTime = new Date(expiry).getTime();

    if (!expiry || !Number.isFinite(expiryTime) ||
        expiryTime <= Date.now()) {
        alert("Please select a future collection deadline.");
        return;
    }

    const food = {
        id: Date.now().toString() + Math.random().toString(36).slice(2, 7),
        name: $("foodName").value.trim(),
        quantity: Number($("quantity").value),
        unit: $("unit").value,
        type: $("foodType").value,
        location: $("foodLocation").value.trim(),
        expiry: new Date(expiryTime).toISOString(),
        description: $("description").value.trim(),
        donor: $("donorName").value.trim(),
        image: selectedImage,
        status: "Available",
        claimedBy: "",
        deliveryPartner: "",
        feedbackSubmitted: false
    };

    if (!food.name || !food.location || !food.donor ||
        !food.description || food.quantity < 1) {
        alert("Please complete all required fields.");
        return;
    }

    foods.unshift(food);

    if (!saveData()) {
        foods.shift();
        return;
    }

    this.reset();
    selectedImage = "";
    $("imagePreview").hidden = true;
    $("donorName").value = currentUser.name;

    renderAll();
    alert("Food donation added to this browser's demo listings!");
});

// RENDER FOOD CARDS
function foodCard(food, buttons = "") {
    const image = food.image
        ? `<img src="${food.image}" alt="Food: ${escapeHTML(food.name)}">`
        : "";

    const deadline = new Date(food.expiry).toLocaleString();

    return `
        <article class="food-card">
            ${image}
            <h3>${escapeHTML(food.name)}</h3>
            ${statusBadge(food.status)}
            <p><strong>Quantity:</strong>
                ${escapeHTML(food.quantity)} ${escapeHTML(food.unit)}</p>
            <p><strong>Type:</strong> ${escapeHTML(food.type)}</p>
            <p><strong>Pickup:</strong> ${escapeHTML(food.location)}</p>
            <p><strong>Donor:</strong> ${escapeHTML(food.donor)}</p>
            <p><strong>Deadline:</strong> ${escapeHTML(deadline)}</p>
            <p>${escapeHTML(food.description)}</p>
            ${buttons}
        </article>
    `;
}

function showEmpty(container, message) {
    container.innerHTML = `<p class="empty">${escapeHTML(message)}</p>`;
}

// DONOR: VIEW OWN FOOD
function renderDonorFoods() {
    const ownFoods = foods.filter(food =>
        food.donor.toLowerCase() === currentUser.name.toLowerCase()
    );

    if (!ownFoods.length) {
        showEmpty($("donorFoods"), "You have not added any food yet.");
        return;
    }

    $("donorFoods").innerHTML = ownFoods.map(food =>
        foodCard(food)
    ).join("");
}

// RECEIVER: SEARCH AND FILTER
function renderReceiverFoods() {
    const query = $("searchInput").value.trim().toLowerCase();
    const type = $("filterType").value;

    const availableFoods = foods.filter(food => {
        const searchable =
            `${food.name} ${food.location} ${food.donor}`.toLowerCase();

        return food.status === "Available" &&
            !isExpired(food) &&
            searchable.includes(query) &&
            (type === "All" || food.type === type);
    });

    if (!availableFoods.length) {
        showEmpty($("receiverFoods"), "No matching food is available right now.");
        return;
    }

    $("receiverFoods").innerHTML = availableFoods.map(food =>
        foodCard(food, `
            <button data-action="claim" data-id="${escapeHTML(food.id)}">
                Claim Food
            </button>
        `)
    ).join("");
}

$("searchInput").addEventListener("input", renderReceiverFoods);
$("filterType").addEventListener("change", renderReceiverFoods);

// CLAIM FOOD
document.addEventListener("click", function(event) {
    const button = event.target.closest("button[data-action]");

    if (!button || !currentUser) return;

    const food = foods.find(item => item.id === button.dataset.id);
    if (!food) return;

    const action = button.dataset.action;

    if (action === "claim" && currentUser.role === "receiver") {
        refreshExpiredFood();

        if (food.status !== "Available" || isExpired(food)) {
            alert("Sorry, this food is no longer available.");
            renderAll();
            return;
        }

        const confirmed = confirm(
            `Claim ${food.name} (${food.quantity} ${food.unit})?`
        );

        if (!confirmed) return;

        const previous = { ...food };

        food.status = "Claimed";
        food.claimedBy = currentUser.name;

        if (!saveData()) {
            Object.assign(food, previous);
            return;
        }

        renderAll();
        alert("Food claimed in this browser's demo!");
    }

    // DELIVERY PARTNER: ADVANCE STATUS
    if (action === "advance" && currentUser.role === "delivery") {
        const allowed = [
            "Claimed",
            "Partner Assigned",
            "Picked Up",
            "On the Way"
        ];

        if (!allowed.includes(food.status)) return;

        const previousStatus = food.status;
        const previousPartner = food.deliveryPartner;

        if (food.status === "Claimed") {
            food.status = "Partner Assigned";
            food.deliveryPartner = currentUser.name;
        } else if (food.status === "Partner Assigned") {
            food.status = "Picked Up";
        } else if (food.status === "Picked Up") {
            food.status = "On the Way";
        } else if (food.status === "On the Way") {
            food.status = "Delivered";
        }

        if (!saveData()) {
            food.status = previousStatus;
            food.deliveryPartner = previousPartner;
            return;
        }

        renderAll();
    }

    // COMPOST PARTNER: ACCEPT ELIGIBLE UNCLAIMED FOOD
    if (action === "compost" && currentUser.role === "compost") {
        if (food.status !== "Unclaimed") return;

        const confirmed = confirm(
            "Mark this unclaimed food as sent to compost processing?"
        );

        if (!confirmed) return;

        food.status = "Sent to Compost";

        if (!saveData()) {
            food.status = "Unclaimed";
            return;
        }

        renderAll();
    }
});

// RECEIVER: TRACK OWN ORDERS
function renderReceiverOrders() {
    const orders = foods.filter(food =>
        food.claimedBy.toLowerCase() === currentUser.name.toLowerCase()
    );

    if (!orders.length) {
        showEmpty($("receiverOrders"), "Your claimed food orders will appear here.");
    } else {
        $("receiverOrders").innerHTML = orders.map(food => `
            <article class="food-card">
                <h3>${escapeHTML(food.name)}</h3>
                ${statusBadge(food.status)}
                <p><strong>Delivery status:</strong> ${escapeHTML(food.status)}</p>
                <p><strong>Delivery partner:</strong>
                    ${escapeHTML(food.deliveryPartner || "Not assigned yet")}</p>
                <p><strong>Pickup location:</strong> ${escapeHTML(food.location)}</p>
                <p class="small">Demo tracking: status is updated manually; GPS is not connected.</p>
            </article>
        `).join("");
    }

    const delivered = orders.filter(food =>
        food.status === "Delivered" && !food.feedbackSubmitted
    );

    $("feedbackOrder").innerHTML = delivered.map(food => `
        <option value="${escapeHTML(food.id)}">
            ${escapeHTML(food.name)} — ${escapeHTML(food.quantity)} ${escapeHTML(food.unit)}
        </option>
    `).join("");

    $("feedbackForm").hidden = delivered.length === 0;

    if (!delivered.length) {
        $("feedbackMessage").hidden = false;
        $("feedbackMessage").textContent =
            "Feedback becomes available after an order is delivered.";
    } else {
        $("feedbackMessage").hidden = true;
    }
}

// DELIVERY PARTNER: VIEW ORDERS
function renderDeliveryOrders() {
    const activeOrders = foods.filter(food =>
        ["Claimed", "Partner Assigned", "Picked Up", "On the Way"].includes(food.status)
    );

    if (!activeOrders.length) {
        showEmpty($("deliveryOrders"), "No active deliveries right now.");
        return;
    }

    $("deliveryOrders").innerHTML = activeOrders.map(food => {
        const isAssigned = food.deliveryPartner === currentUser.name;
        const canAssign = food.status === "Claimed" && !food.deliveryPartner;
        const canAdvance = isAssigned || canAssign;

        return foodCard(food, canAdvance ? `
            <button data-action="advance" data-id="${escapeHTML(food.id)}">
                ${food.status === "Claimed" ? "Accept Delivery" :
                  food.status === "Partner Assigned" ? "Mark Picked Up" :
                  food.status === "Picked Up" ? "Start Delivery" :
                  "Confirm Delivered"}
            </button>
        ` : `
            <p class="small">Assigned to ${escapeHTML(food.deliveryPartner)}</p>
        `);
    }).join("");
}

// COMPOST PARTNER: UNCLAIMED FOOD
function renderCompostFoods() {
    const eligibleFoods = foods.filter(food =>
        food.status === "Unclaimed"
    );

    if (!eligibleFoods.length) {
        showEmpty($("compostFoods"), "No unclaimed food is awaiting processing.");
        return;
    }

    $("compostFoods").innerHTML = eligibleFoods.map(food =>
        foodCard(food, `
            <p class="small">
                Check condition and local processing rules before acceptance.
            </p>
            <button data-action="compost" data-id="${escapeHTML(food.id)}">
                Mark Sent to Compost
            </button>
        `)
    ).join("");
}

// FEEDBACK
$("feedbackForm").addEventListener("submit", function(event) {
    event.preventDefault();

    if (!currentUser || currentUser.role !== "receiver") return;

    const food = foods.find(item =>
        item.id === $("feedbackOrder").value
    );

    if (!food || food.status !== "Delivered" ||
        food.claimedBy.toLowerCase() !== currentUser.name.toLowerCase() ||
        food.feedbackSubmitted) {
        alert("Feedback is available only for your delivered orders.");
        renderAll();
        return;
    }

    const entry = {
        foodId: food.id,
        foodName: food.name,
        receiver: currentUser.name,
        rating: Number($("rating").value),
        comment: $("feedbackText").value.trim()
    };

    if (!entry.comment) {
        alert("Please enter your feedback.");
        return;
    }

    feedbacks.push(entry);
    food.feedbackSubmitted = true;

    if (!saveData()) {
        feedbacks.pop();
        food.feedbackSubmitted = false;
        return;
    }

    $("feedbackText").value = "";
    $("feedbackMessage").hidden = false;
    $("feedbackMessage").textContent =
        "Thank you! Your feedback has been saved in this demo.";

    renderAll();
});

// DASHBOARD COUNTS
function renderStats() {
    $("availableCount").textContent = foods.filter(food =>
        food.status === "Available" && !isExpired(food)
    ).length;

    $("claimedCount").textContent = foods.filter(food =>
        ["Claimed", "Partner Assigned", "Picked Up", "On the Way"].includes(food.status)
    ).length;

    $("deliveredCount").textContent = foods.filter(food =>
        food.status === "Delivered"
    ).length;
}

function renderAll() {
    if (!currentUser) return;

    refreshExpiredFood();
    renderStats();

    if (currentUser.role === "donor") renderDonorFoods();

    if (currentUser.role === "receiver") {
        renderReceiverFoods();
        renderReceiverOrders();
    }

    if (currentUser.role === "delivery") renderDeliveryOrders();

    if (currentUser.role === "compost") renderCompostFoods();
}

// Update availability when the page is revisited or refreshed.
refreshExpiredFood();
